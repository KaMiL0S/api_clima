
(function($) {
    "use strict";

    // Add active state to sidbar nav links
    var path = window.location.href; // because the 'href' property of the DOM element is the absolute path
        $("#layoutSidenav_nav .sb-sidenav a.nav-link").each(function() {
            if (this.href === path) {
                $(this).addClass("active");
            }
        });

    // Toggle the side navigation
    $("#sidebarToggle").on("click", function(e) {
        e.preventDefault();
        $("body").toggleClass("sb-sidenav-toggled");
    });


    //Crear usuarios
    $('#crear_cuenta').on('click', function(){
        let DataUser = [];
        let conteo = 0;
        $('#Registro input').each(function(){
            let registro = $(this).val();
            if (registro == "") {
                conteo++
            }else{
                DataUser.push(registro);
            }
        });
        if (conteo > 0) {
            swal("Faltan campos por llenar", "Por favor ingrese todos los campos", "warning");
        }else{
            $.ajax({
                method: 'post',
                url: 'app/controller/ctrClima.php',
                data: {
                    DataUser: DataUser,
                    action: 'CrearUsuario'
                }
            }).done(function(result){
                console.log(result);
                if (result) {
                    swal("¡Bien!", "usuario creado correctamente", "success");
                    window.location.href = 'index.php';
                }else{
                    swal("¡oh algo a ocurrido!", "result.msg", "warning");
                }
            });
        }
    });

    //Eliminar usuarios
    $('#eliminar').on('click', function(){
        $('#modificar').hide();
        $('#inicio').hide();
        $('#mensaje_todos').hide();
        $('#eliminar_usuarios').show();
    });

    $('.eliminar_usu').on('click', function(){
        let eliminar = $(this).attr('id');
        eliminar = eliminar.slice(-1);
        let IdCelda = $('.id_'+eliminar).text();
        $.ajax({
            method: 'post',
            url: 'controller/ctrClima.php',
            data: {
                DataId: IdCelda,
                action: 'eliminarUsuario'
            }
        }).done( function(result){
            setInterval('location.reload()',1100);
        });
    });

    //Comentario
    $('#mensaje').on('click', function(){
        $('#modificar').hide();
        $('#inicio').hide();
        $('#eliminar_usuarios').hide();
        $('#mensaje_todos').show();
    });

    $('#newComentario').on('click', function(){
        let comentario = $('#comment').val();
        $.ajax({
            method: 'post',
            url: 'controller/ctrClima.php',
            data: {
                comentario: comentario,
                action: 'guardarComentarios'
            }
        }).done( function(result){
            console.log(result);
            if (result) {
                swal("¡Bien!", "comentario añadido correctamente", "success");
                setInterval('location.reload()',1100);
            }
        });
        $('#inicio').hide();
        $('#eliminar_usuarios').hide();
        $('#mensaje_todos').show();
    });

    $('.modif_usu').on('click', function(){
        let modibtn = $(this).attr('id');
        modibtn = modibtn.slice(-1);
        let IdCelda = $('.id_'+modibtn).text();
        $.ajax({
            method: 'post',
            url: 'controller/ctrClima.php',
            data: {
                DataId: IdCelda,
                action: 'LoadUsuario'
            }
        }).done( function(result){
            let dataJson = JSON.parse(result);
            $('#inicio').hide();
            $('#eliminar_usuarios').hide();
            $('#mensaje_todos').hide();
            $('#modificar').show();
            $('#id_mod').val(dataJson.id);
            $('#usuario_mod').val(dataJson.usuario);
            $('#password_mod').val(dataJson.password);
            $('#nombre_mod').val(dataJson.nombre);
            $('#tipo_usuario_mod').val(dataJson.tipo_usuario);
        });
    });

    $('#btn_Mod').on('click', function(){
        $.ajax({
            method: 'post',
            url: 'controller/ctrClima.php',
            data: {
                id_mod: $('#id_mod').val(),
                usuario_mod: $('#usuario_mod').val(),
                password_mod: $('#password_mod').val(),
                nombre_mod: $('#nombre_mod').val(),
                action: 'modificarUsuario'
            }
        }).done( function(){
            swal("¡Bien!", "Usuario modificado exitosamente", "success");
            setInterval('location.reload()',1100);
        });
    });

})(jQuery);
