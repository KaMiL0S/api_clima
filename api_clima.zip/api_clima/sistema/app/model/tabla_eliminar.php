<?php
include '../config/conexion.php';
$conteo = 0;
$sql = "SELECT id, usuario, password, nombre, tipo_usuario FROM usuarios WHERE tipo_usuario='2'";
    $resultado = $mysqli->query($sql);
    while($row = $resultado->fetch_array(MYSQLI_ASSOC)){
        $conteo++;
        echo "<tr><td class='id_".$conteo."'>" . 
            $row["id"] . "</td>";
        echo "<td class='usuario_".$conteo."'>" . 
            $row["usuario"] . "</td>";
        echo "<td class='pass_".$conteo."'>" . 
            $row["password"] . "</td>";
        echo "<td class='nom_".$conteo."'>" . 
            $row["nombre"] . "</td>";
        echo "<td><button class='button btn btn-primary eliminar_usu' id='elimi".$conteo."'>Eliminar</button></td>";
        echo "<td><button class='button btn btn-success modif_usu' id='modif".$conteo."'>Modificar</button></td></tr>"; 
    };

?>