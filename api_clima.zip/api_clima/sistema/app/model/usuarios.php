<?php
require_once "../../config/conexion.php";
session_start();

class ApiClima
{

    public function insertUsuario($data){

    	global $mysqli;
    	$NOMBRES = $data[0];
    	$APELLIDOS = $data[1];
    	$EMAIL = $data[2];
    	$PASSWORD = sha1($data[3]);
    	$CONPASSWORD = $data[4];
    	$NOMBRE_COMPLETO = $NOMBRES." ".$APELLIDOS;

    	$sql = "INSERT INTO usuarios (usuario, password, nombre, tipo_usuario)VALUES('$EMAIL','$PASSWORD','$NOMBRE_COMPLETO', '2')";
    	$resultado = $mysqli->query($sql);

    	if ($resultado) {
    		return true;
    	}else{
    		return false;
    	}
    }

    public function eliminarUsuario($data){

        global $mysqli;
        $ID_USUARIO = $data;
        $sql = "DELETE FROM usuarios WHERE id='$ID_USUARIO'";
        $resultado = $mysqli->query($sql);
        return $resultado;
    }

    public function guardarComentrios($data){

        global $mysqli;
        $fecha_registro = date('Y-m-d H:i:s');
        $comentario = $data;
        $usuarioId = $_SESSION['id'];
        $sql = "INSERT INTO comentarios(fecha, usuario, comentario)VALUES('$fecha_registro', '$usuarioId','$comentario')";
        $resultado = $mysqli->query($sql);
        return $resultado;
    }

    public function LoadUsuario($data){
        
        global $mysqli;
        $ID_USUARIO = $data;
        $sql = "SELECT id, usuario, password, nombre, tipo_usuario FROM usuarios WHERE id='$ID_USUARIO'";
        $resultado = $mysqli->query($sql);
        $row = $resultado->fetch_array(MYSQLI_ASSOC);
        return $row;
    }

    public function modificarUsuario($data){

        global $mysqli;
        $id_mod = $data[0];
        $usuario_mod = $data[1];
        $password_mod = $data[2];
        $nombre_mod = $data[3];
        $sql = "UPDATE usuarios SET nombre='$nombre_mod', password='$password_mod' WHERE id='$id_mod'";
        $resultado = $mysqli->query($sql);
        return $resultado;
    }
}


?>