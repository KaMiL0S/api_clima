<?php
	include '../config/conexion.php';

	$conteo = 0;
	$sql = "SELECT id, fecha, usuario, comentario FROM comentarios";
	$resultado = $mysqli->query($sql);

	while($row = $resultado->fetch_array(MYSQLI_ASSOC)){
	 	$conteo++;
	 	echo "<tr><td class='idcom_".$conteo."'>" . 
            $row["id"] . "</td>";
        echo "<td class='fechacom_".$conteo."'>" . 
            $row["fecha"] . "</td>";
        echo "<td class='usuariocom_".$conteo."'>" . 
            $row["usuario"] . "</td>";
        echo "<td class='coment_".$conteo."'>" . 
            $row["comentario"] . "</td>";
	};
?>