<div>
	<label>Comentarios anteriores</label>
	<table class="table table-bordered" id="dataTable1" width="100%" cellspacing="0">
		<thead>
			<th>id</th>
			<th>fecha</th>
			<th>id usuario</th>
			<th>comentario</th>
		</thead>
		<?php include 'model/comentariosAnteriores.php'; ?>
	</table>
	<label>Añade un comentario</label>
	<textarea class="form-control" rows="3" id="comment"></textarea><br>
	<button class="button btn btn-primary" id="newComentario">Añadir</button>
</div>