<?php
include '../model/usuarios.php';

$apiclima = new ApiClima();
$action = $_POST['action'];

if (isset($action)) {
    switch ($action){
        case 'CrearUsuario':
        	$post = $_POST['DataUser'];
            $result = $apiclima->insertUsuario($post);
            echo json_encode($result);
            break;
        case 'eliminarUsuario':
        	$post = $_POST['DataId'];
            $result = $apiclima->eliminarUsuario($post);
            echo json_encode($result);  
            break;
        case 'guardarComentarios':
        	$post = $_POST['comentario'];
            $result = $apiclima->guardarComentrios($post);
            echo json_encode($result);  
            break;
        case 'LoadUsuario':
        	$post = $_POST['DataId'];
            $result = $apiclima->LoadUsuario($post);
            echo json_encode((array)$result);  
            break;
        case 'modificarUsuario':
        	$post = [];
        	array_push($post, $_POST['id_mod']);
        	array_push($post, $_POST['usuario_mod']);
        	array_push($post, $_POST['password_mod']);
        	array_push($post, $_POST['nombre_mod']);
            $result = $apiclima->modificarUsuario($post);
            echo json_encode($result);  
            break;
        default:
            $usuarios->return->bool = false;
            $usuarios->return->msg = 'Acción No Encontrada';
            break;
    } 
}

?>